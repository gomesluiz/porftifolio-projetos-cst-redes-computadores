﻿using MyApp;
using System;
using System.Security.Cryptography.X509Certificates;


namespace MyApp // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        static void Main(string[] args)
        {

            var computadorA = new Computador();

            computadorA.nome = "Computador A";
            Console.WriteLine("Digite o Mac adress de origem:");
            computadorA.Mac = Console.ReadLine();
            Console.WriteLine("Digite o Ip de origem:");
            computadorA.Ip = Console.ReadLine();

            var computadorB = new Computador();
            computadorB.nome = "Computador B";
            Console.WriteLine("Digite o Mac adress de destino:");
            computadorB.Mac = Console.ReadLine();
            Console.WriteLine("Digite o Ip de destino:");
            computadorB.Ip = Console.ReadLine();


            Console.WriteLine("\nProtocolo TCP/IP");
            Console.Write("Entre com a mensagem:");
            computadorA.aplicacao.dado = Console.ReadLine();
            computadorA.aplicacao.Send();
            Console.WriteLine($"\n\nMAC ADRESS COMPUTADOR ORIGEM: {computadorA.Mac}.\nIP COMPUTADOR ORIGEM:{computadorA.Ip}.\nMAC ADRESS COMPUTADOR DESTINO: {computadorB.Mac}.\nIP COMPUTADOR DESTINO:{computadorB.Ip}. ");

            Thread.Sleep(5000);

            int tamanho = 10; // Tamanho do quadrado
            int larguraTerminal = Console.WindowWidth;
            int alturaTerminal = Console.WindowHeight;

            while (true)
            {
                for (int i = 0; i < alturaTerminal - tamanho; i++)
                {
                    Console.Clear(); // Limpa o console para desenhar o novo quadrado
                    DesenharQuadrado(i, tamanho); // Desenha o quadrado na posição atual

                    Thread.Sleep(100); // Aguarda um curto período antes de mover o quadrado

                }
            }
            Console.ReadKey();
        }
        static void DesenharQuadrado(int posicao, int tamanho)
        {
            for (int i = 0; i < tamanho; i++)
            {
                Console.SetCursorPosition(5, i + posicao);
                for (int j = 0; j < tamanho; j++)
                {
                    if (i == 0 || i == tamanho - 1 || j == 0 || j == tamanho - 1)
                    {
                        Console.Write("* "); // Caractere do quadrado
                    }
                    else
                    {
                        Console.Write("  "); // Espaço interno do quadrado
                    }


                }


            }

            Console.SetCursorPosition(7, posicao + 1);
            Console.Write("Interface");

            if (posicao > 3)
            {
                Console.SetCursorPosition(7, posicao + 3);
                Console.Write("Rede");
            }
            if (posicao > 7)
            {
                Console.SetCursorPosition(7, posicao + 5);
                Console.Write("Transporte");
            }
            if (posicao > 11)
            {
                Console.SetCursorPosition(7, posicao + 7);
                Console.Write("Aplicação");
            }

        }
    }


    internal class Computador
    {
        public string nome = "";
        public string Ip = "";
        public string Mac = "";
        public Aplicacao aplicacao = new Aplicacao();
    }


    internal class Aplicacao
    {
        public string dado = " ";

        public void Send()
        {
            Thread.Sleep(1500);
            Console.Write("\n" + dado + "-->" + "SEND APLICAÇÃO -->");
            var servico_transporte = new Transporte();
            servico_transporte.Send(dado);
        }
        public void Receive(string dado)
        {

            Thread.Sleep(1500);
            Console.Write("RECEIVE APLICAÇÃO -->" + dado);





        }
    }

    internal class Transporte
    {
        public static readonly int TCP = 1;
        public static readonly int UDP = 2;
        public int Protocolo;
        public int porta_origem;
        public int porta_destino;
        public string dado = "";


        public void Send(string dado)
        {
            var pdu_transporte = new Transporte();
            Thread.Sleep(1500);
            pdu_transporte.Protocolo = Transporte.UDP;
            pdu_transporte.porta_origem = 8080;
            pdu_transporte.porta_destino = 123;
            pdu_transporte.dado = dado;
            Console.Write("SEND TRANSPORTE -->");
            var servico_rede = new Rede();
            servico_rede.Send(pdu_transporte);

        }

        public void Receive(Transporte pdu_transporte)
        {
            Thread.Sleep(1000);
            Console.Write("RECEIVE TRANSPORTE ----->");
            var servico_aplicacao = new Aplicacao();
            servico_aplicacao.Receive(pdu_transporte.dado);
        }
    }




    internal class Rede

    {
        //cabeçalho
        public string IpDest = " ";
        public string IpOrig = " ";
        public string ProtocoloIP = " ";

        //dado
        public Transporte dado = new Transporte();
        public void Send(Transporte pdu_transporte)
        {
            var pdu_rede = new Rede();
            var computadorA = new Computador();
            var computadorB = new Computador();
            pdu_rede.dado = pdu_transporte;
            Thread.Sleep(1500);
            pdu_rede.ProtocoloIP = "IPV4";
            pdu_rede.IpOrig = computadorA.Ip;
            pdu_rede.IpDest = computadorB.Ip;
            Console.Write("SEND REDE ------->");
            var servico_enlace = new Enlace();
            servico_enlace.Send(pdu_rede);

        }
        public void Receive(Rede pdu_rede)
        {
            Thread.Sleep(1500);
            Console.Write("RECEIVE REDE ------->");
            var servico_transporte = new Transporte();
            servico_transporte.Receive(pdu_rede.dado);

        }
    }


    internal class Enlace

    {
        //cabeçalho
        public string MacDest = "";
        public string MacOrig = "";

        //dado
        public Rede dado = new Rede();
        public void Send(Rede pdu_rede)
        {
            var pdu_enlace = new Enlace();
            var computadorA = new Computador();
            var computadorB = new Computador();
            pdu_enlace.dado = pdu_rede;
            pdu_enlace.MacOrig = computadorA.Mac;
            pdu_enlace.MacDest = computadorB.Mac;
            Thread.Sleep(1500);
            Console.Write("SEND ENLACE ----->");
            var servico_enlace = new Enlace();
            servico_enlace.Receive(pdu_enlace);
        }
        public void Receive(Enlace pdu_enlace)
        {
            Thread.Sleep(1500);
            Console.Write("\nRECEIVE ENLACE ----->");
            var servico_rede = new Rede();
            servico_rede.Receive(pdu_enlace.dado);
        }
    }
}

